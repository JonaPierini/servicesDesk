sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("servicesdesk.tiposolicitud.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);